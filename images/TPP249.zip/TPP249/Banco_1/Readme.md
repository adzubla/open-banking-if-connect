# Readme file for TPP249 

## Client Details 
 clientID=47f94468-3192-4192-b4ec-01e03c474cf7 
 clientSecret=0ae34c65-6c69-419e-a498-83bb28405c52 

## Organisation Details 
 orgName=TPP249 
 orgID=a5825465-f058-4895-8f9f-0afc79b2b2a8 

## Software Details 
 softwareName=TPP249 
 softwareID=51c03d68-c90f-4c4e-99ee-31162c8f3844 

## Cert KID Details 
 transportKID=koApKVHkCtp_2X1Y2Rpexhb-AhRF4_TKWwSTr5BYYZA 
 signingKID=3f2MCphSu5g8B8SWVbspmXc1Xsnge86XJrCmzCrPUTI 

## Cert Pem Details 
 transportPEM=https://tecban-uat-us-east-1-keystore.s3.amazonaws.com/a5825465-f058-4895-8f9f-0afc79b2b2a8/51c03d68-c90f-4c4e-99ee-31162c8f3844/koApKVHkCtp_2X1Y2Rpexhb-AhRF4_TKWwSTr5BYYZA.pem 
 signingPEM=https://tecban-uat-us-east-1-keystore.s3.amazonaws.com/a5825465-f058-4895-8f9f-0afc79b2b2a8/51c03d68-c90f-4c4e-99ee-31162c8f3844/3f2MCphSu5g8B8SWVbspmXc1Xsnge86XJrCmzCrPUTI.pem 

## Server Details 
 Well Known Endpoint=https://auth1.tecban-sandbox.o3bank.co.uk/.well-known/openid-configuration 
 Token Endpoint=https://as1.tecban-sandbox.o3bank.co.uk/token 
 Resource Endpoint=https://rs1.tecban-sandbox.o3bank.co.uk 
 Auth Endpoint=https://auth1.tecban-sandbox.o3bank.co.uk/auth 

 ## User & Account Details 
 [
  {
    "username": "team249b1u1",
    "password": "245592",
    "accounts": [
      {
        "accountNumber": "01249001001"
      },
      {
        "accountNumber": "01249001002"
      },
      {
        "accountNumber": "01249001003"
      }
    ]
  },
  {
    "username": "team249b1u2",
    "password": "971917",
    "accounts": [
      {
        "accountNumber": "01249002001"
      },
      {
        "accountNumber": "01249002002"
      },
      {
        "accountNumber": "01249002003"
      }
    ]
  },
  {
    "username": "team249b1u3",
    "password": "170119",
    "accounts": [
      {
        "accountNumber": "01249003001"
      },
      {
        "accountNumber": "01249003002"
      },
      {
        "accountNumber": "01249003003"
      }
    ]
  },
  {
    "username": "team249b1u4",
    "password": "541380",
    "accounts": [
      {
        "accountNumber": "01249004001"
      },
      {
        "accountNumber": "01249004002"
      },
      {
        "accountNumber": "01249004003"
      }
    ]
  },
  {
    "username": "team249b1u5",
    "password": "214262",
    "accounts": [
      {
        "accountNumber": "01249005001"
      },
      {
        "accountNumber": "01249005002"
      },
      {
        "accountNumber": "01249005003"
      }
    ]
  }
] 

## Tip for testing in postman 
 In postman settings - certificates tab - add the transport cert and key for the rs and token endpoints 

