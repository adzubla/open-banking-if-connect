# Readme file for TPP249 

## Client Details 
 clientID=d257dbcc-b6d0-416d-aa3c-4b62ad349930 
 clientSecret=48cf46cf-5fed-4a4b-8db5-c9e695e4bc86 

## Organisation Details 
 orgName=TPP249 
 orgID=95878d19-ece3-4eec-9c0e-b575be54f3a1 

## Software Details 
 softwareName=TPP249 
 softwareID=20ac8ed1-7e90-46f1-a1b1-17760259ca10 

## Cert KID Details 
 transportKID=6h0-eOjIKZADz6YOOyaOZ0zaKmsxVfnGArh_NxbWOeY 
 signingKID=skos0wEyZJpOs4a1U39aeI6hZkeBKneVUDoVYpXNE-8 

## Cert Pem Details 
 transportPEM=https://tecban-uat-us-east-1-keystore.s3.amazonaws.com/95878d19-ece3-4eec-9c0e-b575be54f3a1/20ac8ed1-7e90-46f1-a1b1-17760259ca10/6h0-eOjIKZADz6YOOyaOZ0zaKmsxVfnGArh_NxbWOeY.pem 
 signingPEM=https://tecban-uat-us-east-1-keystore.s3.amazonaws.com/95878d19-ece3-4eec-9c0e-b575be54f3a1/20ac8ed1-7e90-46f1-a1b1-17760259ca10/skos0wEyZJpOs4a1U39aeI6hZkeBKneVUDoVYpXNE-8.pem 

## Server Details 
 Well Known Endpoint=https://auth2.tecban-sandbox.o3bank.co.uk/.well-known/openid-configuration 
 Token Endpoint=https://as2.tecban-sandbox.o3bank.co.uk/token 
 Resource Endpoint=https://rs2.tecban-sandbox.o3bank.co.uk 
 Auth Endpoint=https://auth2.tecban-sandbox.o3bank.co.uk/auth 

 ## User & Account Details 
 [
  {
    "username": "team249b2u1",
    "password": "883298",
    "accounts": [
      {
        "accountNumber": "02249001001"
      },
      {
        "accountNumber": "02249001002"
      },
      {
        "accountNumber": "02249001003"
      }
    ]
  },
  {
    "username": "team249b2u2",
    "password": "829907",
    "accounts": [
      {
        "accountNumber": "02249002001"
      },
      {
        "accountNumber": "02249002002"
      },
      {
        "accountNumber": "02249002003"
      }
    ]
  },
  {
    "username": "team249b2u3",
    "password": "935036",
    "accounts": [
      {
        "accountNumber": "02249003001"
      },
      {
        "accountNumber": "02249003002"
      },
      {
        "accountNumber": "02249003003"
      }
    ]
  },
  {
    "username": "team249b2u4",
    "password": "310095",
    "accounts": [
      {
        "accountNumber": "02249004001"
      },
      {
        "accountNumber": "02249004002"
      },
      {
        "accountNumber": "02249004003"
      }
    ]
  },
  {
    "username": "team249b2u5",
    "password": "221311",
    "accounts": [
      {
        "accountNumber": "02249005001"
      },
      {
        "accountNumber": "02249005002"
      },
      {
        "accountNumber": "02249005003"
      }
    ]
  }
] 

## Tip for testing in postman 
 In postman settings - certificates tab - add the transport cert and key for the rs and token endpoints 

